```
@Copyright:LintCode
@Author:   linicam
@Problem:  http://www.lintcode.com/problem/unique-binary-search-trees
@Language: Markdown
@Datetime: 16-12-21 02:12
```

https://leetcode.com/problems/unique-binary-search-trees/
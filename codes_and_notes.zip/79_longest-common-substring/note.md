```
@Copyright:LintCode
@Author:   linicam
@Problem:  http://www.lintcode.com/problem/longest-common-substring
@Language: Markdown
@Datetime: 16-12-29 14:16
```

DP
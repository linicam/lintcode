```
@Copyright:LintCode
@Author:   linicam
@Problem:  http://www.lintcode.com/problem/3sum
@Language: Markdown
@Datetime: 16-12-20 00:12
```

[0,0,0]
相同的一队列数，取第一个
如果不等于0，不用管重复的问题，只有等于0的时候才要去重
也可以最后结果去重
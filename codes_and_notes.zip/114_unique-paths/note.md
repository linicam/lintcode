```
@Copyright:LintCode
@Author:   linicam
@Problem:  http://www.lintcode.com/problem/unique-paths
@Language: Markdown
@Datetime: 16-12-20 23:50
```

总共m + n -2步，n-1步向下，m-1步向右，所问即求排列(n - 1)C(m + n -2)